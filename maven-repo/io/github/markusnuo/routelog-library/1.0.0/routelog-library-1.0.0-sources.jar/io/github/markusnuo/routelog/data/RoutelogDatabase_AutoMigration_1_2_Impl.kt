package io.github.markusnuo.routelog.`data`

import androidx.room.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Suppress

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
internal class RoutelogDatabase_AutoMigration_1_2_Impl : Migration {
  public constructor() : super(1, 2)

  public override fun migrate(connection: SQLiteConnection) {
    connection.execSQL("CREATE TABLE IF NOT EXISTS `uploads` (`recording_id` INTEGER NOT NULL, `upload_url` TEXT NOT NULL, `host` TEXT NOT NULL, `label` TEXT, `expires_at_millis` INTEGER NOT NULL, `state` TEXT NOT NULL, `attempts` INTEGER NOT NULL, `last_http_status` INTEGER, `finished_at_millis` INTEGER, `route_deleted_at_millis` INTEGER, PRIMARY KEY(`recording_id`), FOREIGN KEY(`recording_id`) REFERENCES `recordings`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
    connection.execSQL("CREATE TABLE IF NOT EXISTS `grants` (`token_hash` TEXT NOT NULL, `recording_id` INTEGER, `expires_at_millis` INTEGER NOT NULL, PRIMARY KEY(`token_hash`), FOREIGN KEY(`recording_id`) REFERENCES `recordings`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )")
    connection.execSQL("CREATE INDEX IF NOT EXISTS `index_grants_recording_id` ON `grants` (`recording_id`)")
  }
}
