package io.github.markusnuo.routelog.`data`

import androidx.collection.LongSparseArray
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndex
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.getTotalChangedRows
import androidx.room.util.performBlocking
import androidx.room.util.recursiveFetchLongSparseArray
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Double
import kotlin.Float
import kotlin.IllegalArgumentException
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class RecordingDao_Impl(
  __db: RoomDatabase,
) : RecordingDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfRecordingEntity: EntityInsertAdapter<RecordingEntity>

  private val __insertAdapterOfTrackPointEntity: EntityInsertAdapter<TrackPointEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfRecordingEntity = object : EntityInsertAdapter<RecordingEntity>() {
      protected override fun createQuery(): String = "INSERT OR ABORT INTO `recordings` (`id`,`started_at_millis`,`ended_at_millis`,`state`,`distance_meters`,`point_count`,`last_point_at_millis`,`segment`,`alive_at_millis`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: RecordingEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.startedAtMillis)
        val _tmpEndedAtMillis: Long? = entity.endedAtMillis
        if (_tmpEndedAtMillis == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpEndedAtMillis)
        }
        statement.bindText(4, __RecordingState_enumToString(entity.state))
        statement.bindDouble(5, entity.distanceMeters)
        statement.bindLong(6, entity.pointCount.toLong())
        val _tmpLastPointAtMillis: Long? = entity.lastPointAtMillis
        if (_tmpLastPointAtMillis == null) {
          statement.bindNull(7)
        } else {
          statement.bindLong(7, _tmpLastPointAtMillis)
        }
        statement.bindLong(8, entity.segment.toLong())
        val _tmpAliveAtMillis: Long? = entity.aliveAtMillis
        if (_tmpAliveAtMillis == null) {
          statement.bindNull(9)
        } else {
          statement.bindLong(9, _tmpAliveAtMillis)
        }
      }
    }
    this.__insertAdapterOfTrackPointEntity = object : EntityInsertAdapter<TrackPointEntity>() {
      protected override fun createQuery(): String = "INSERT OR ABORT INTO `track_points` (`id`,`recording_id`,`segment`,`time_millis`,`latitude`,`longitude`,`altitude_meters`,`msl_altitude_meters`,`accuracy_meters`,`speed_mps`,`bearing_degrees`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TrackPointEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.recordingId)
        statement.bindLong(3, entity.segment.toLong())
        statement.bindLong(4, entity.timeMillis)
        statement.bindDouble(5, entity.latitude)
        statement.bindDouble(6, entity.longitude)
        val _tmpAltitudeMeters: Double? = entity.altitudeMeters
        if (_tmpAltitudeMeters == null) {
          statement.bindNull(7)
        } else {
          statement.bindDouble(7, _tmpAltitudeMeters)
        }
        val _tmpMslAltitudeMeters: Double? = entity.mslAltitudeMeters
        if (_tmpMslAltitudeMeters == null) {
          statement.bindNull(8)
        } else {
          statement.bindDouble(8, _tmpMslAltitudeMeters)
        }
        val _tmpAccuracyMeters: Float? = entity.accuracyMeters
        if (_tmpAccuracyMeters == null) {
          statement.bindNull(9)
        } else {
          statement.bindDouble(9, _tmpAccuracyMeters.toDouble())
        }
        val _tmpSpeedMetersPerSecond: Float? = entity.speedMetersPerSecond
        if (_tmpSpeedMetersPerSecond == null) {
          statement.bindNull(10)
        } else {
          statement.bindDouble(10, _tmpSpeedMetersPerSecond.toDouble())
        }
        val _tmpBearingDegrees: Float? = entity.bearingDegrees
        if (_tmpBearingDegrees == null) {
          statement.bindNull(11)
        } else {
          statement.bindDouble(11, _tmpBearingDegrees.toDouble())
        }
      }
    }
  }

  public override fun insertRecording(recording: RecordingEntity): Long = performBlocking(__db, false, true) { _connection ->
    val _result: Long = __insertAdapterOfRecordingEntity.insertAndReturnId(_connection, recording)
    _result
  }

  public override fun insertPoint(point: TrackPointEntity): Long = performBlocking(__db, false, true) { _connection ->
    val _result: Long = __insertAdapterOfTrackPointEntity.insertAndReturnId(_connection, point)
    _result
  }

  public override fun recording(id: Long): RecordingEntity? {
    val _sql: String = "SELECT * FROM recordings WHERE id = ?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfStartedAtMillis: Int = getColumnIndexOrThrow(_stmt, "started_at_millis")
        val _columnIndexOfEndedAtMillis: Int = getColumnIndexOrThrow(_stmt, "ended_at_millis")
        val _columnIndexOfState: Int = getColumnIndexOrThrow(_stmt, "state")
        val _columnIndexOfDistanceMeters: Int = getColumnIndexOrThrow(_stmt, "distance_meters")
        val _columnIndexOfPointCount: Int = getColumnIndexOrThrow(_stmt, "point_count")
        val _columnIndexOfLastPointAtMillis: Int = getColumnIndexOrThrow(_stmt, "last_point_at_millis")
        val _columnIndexOfSegment: Int = getColumnIndexOrThrow(_stmt, "segment")
        val _columnIndexOfAliveAtMillis: Int = getColumnIndexOrThrow(_stmt, "alive_at_millis")
        val _result: RecordingEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpStartedAtMillis: Long
          _tmpStartedAtMillis = _stmt.getLong(_columnIndexOfStartedAtMillis)
          val _tmpEndedAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfEndedAtMillis)) {
            _tmpEndedAtMillis = null
          } else {
            _tmpEndedAtMillis = _stmt.getLong(_columnIndexOfEndedAtMillis)
          }
          val _tmpState: RecordingState
          _tmpState = __RecordingState_stringToEnum(_stmt.getText(_columnIndexOfState))
          val _tmpDistanceMeters: Double
          _tmpDistanceMeters = _stmt.getDouble(_columnIndexOfDistanceMeters)
          val _tmpPointCount: Int
          _tmpPointCount = _stmt.getLong(_columnIndexOfPointCount).toInt()
          val _tmpLastPointAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfLastPointAtMillis)) {
            _tmpLastPointAtMillis = null
          } else {
            _tmpLastPointAtMillis = _stmt.getLong(_columnIndexOfLastPointAtMillis)
          }
          val _tmpSegment: Int
          _tmpSegment = _stmt.getLong(_columnIndexOfSegment).toInt()
          val _tmpAliveAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfAliveAtMillis)) {
            _tmpAliveAtMillis = null
          } else {
            _tmpAliveAtMillis = _stmt.getLong(_columnIndexOfAliveAtMillis)
          }
          _result = RecordingEntity(_tmpId,_tmpStartedAtMillis,_tmpEndedAtMillis,_tmpState,_tmpDistanceMeters,_tmpPointCount,_tmpLastPointAtMillis,_tmpSegment,_tmpAliveAtMillis)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun recordingsInProgress(): List<RecordingEntity> {
    val _sql: String = "SELECT * FROM recordings WHERE state = 'RECORDING'"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfStartedAtMillis: Int = getColumnIndexOrThrow(_stmt, "started_at_millis")
        val _columnIndexOfEndedAtMillis: Int = getColumnIndexOrThrow(_stmt, "ended_at_millis")
        val _columnIndexOfState: Int = getColumnIndexOrThrow(_stmt, "state")
        val _columnIndexOfDistanceMeters: Int = getColumnIndexOrThrow(_stmt, "distance_meters")
        val _columnIndexOfPointCount: Int = getColumnIndexOrThrow(_stmt, "point_count")
        val _columnIndexOfLastPointAtMillis: Int = getColumnIndexOrThrow(_stmt, "last_point_at_millis")
        val _columnIndexOfSegment: Int = getColumnIndexOrThrow(_stmt, "segment")
        val _columnIndexOfAliveAtMillis: Int = getColumnIndexOrThrow(_stmt, "alive_at_millis")
        val _result: MutableList<RecordingEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: RecordingEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpStartedAtMillis: Long
          _tmpStartedAtMillis = _stmt.getLong(_columnIndexOfStartedAtMillis)
          val _tmpEndedAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfEndedAtMillis)) {
            _tmpEndedAtMillis = null
          } else {
            _tmpEndedAtMillis = _stmt.getLong(_columnIndexOfEndedAtMillis)
          }
          val _tmpState: RecordingState
          _tmpState = __RecordingState_stringToEnum(_stmt.getText(_columnIndexOfState))
          val _tmpDistanceMeters: Double
          _tmpDistanceMeters = _stmt.getDouble(_columnIndexOfDistanceMeters)
          val _tmpPointCount: Int
          _tmpPointCount = _stmt.getLong(_columnIndexOfPointCount).toInt()
          val _tmpLastPointAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfLastPointAtMillis)) {
            _tmpLastPointAtMillis = null
          } else {
            _tmpLastPointAtMillis = _stmt.getLong(_columnIndexOfLastPointAtMillis)
          }
          val _tmpSegment: Int
          _tmpSegment = _stmt.getLong(_columnIndexOfSegment).toInt()
          val _tmpAliveAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfAliveAtMillis)) {
            _tmpAliveAtMillis = null
          } else {
            _tmpAliveAtMillis = _stmt.getLong(_columnIndexOfAliveAtMillis)
          }
          _item = RecordingEntity(_tmpId,_tmpStartedAtMillis,_tmpEndedAtMillis,_tmpState,_tmpDistanceMeters,_tmpPointCount,_tmpLastPointAtMillis,_tmpSegment,_tmpAliveAtMillis)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeRecordingList(): Flow<List<RecordingListItem>> {
    val _sql: String = "SELECT * FROM recordings ORDER BY started_at_millis DESC, id DESC"
    return createFlow(__db, true, arrayOf("uploads", "recordings")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfStartedAtMillis: Int = getColumnIndexOrThrow(_stmt, "started_at_millis")
        val _columnIndexOfEndedAtMillis: Int = getColumnIndexOrThrow(_stmt, "ended_at_millis")
        val _columnIndexOfState: Int = getColumnIndexOrThrow(_stmt, "state")
        val _columnIndexOfDistanceMeters: Int = getColumnIndexOrThrow(_stmt, "distance_meters")
        val _columnIndexOfPointCount: Int = getColumnIndexOrThrow(_stmt, "point_count")
        val _columnIndexOfLastPointAtMillis: Int = getColumnIndexOrThrow(_stmt, "last_point_at_millis")
        val _columnIndexOfSegment: Int = getColumnIndexOrThrow(_stmt, "segment")
        val _columnIndexOfAliveAtMillis: Int = getColumnIndexOrThrow(_stmt, "alive_at_millis")
        val _collectionUpload: LongSparseArray<UploadStatus?> = LongSparseArray<UploadStatus?>()
        while (_stmt.step()) {
          val _tmpKey: Long
          _tmpKey = _stmt.getLong(_columnIndexOfId)
          _collectionUpload.put(_tmpKey, null)
        }
        _stmt.reset()
        __fetchRelationshipuploadsAsioGithubMarkusnuoRoutelogDataUploadStatus(_connection, _collectionUpload)
        val _result: MutableList<RecordingListItem> = mutableListOf()
        while (_stmt.step()) {
          val _item: RecordingListItem
          val _tmpRecording: RecordingEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpStartedAtMillis: Long
          _tmpStartedAtMillis = _stmt.getLong(_columnIndexOfStartedAtMillis)
          val _tmpEndedAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfEndedAtMillis)) {
            _tmpEndedAtMillis = null
          } else {
            _tmpEndedAtMillis = _stmt.getLong(_columnIndexOfEndedAtMillis)
          }
          val _tmpState: RecordingState
          _tmpState = __RecordingState_stringToEnum(_stmt.getText(_columnIndexOfState))
          val _tmpDistanceMeters: Double
          _tmpDistanceMeters = _stmt.getDouble(_columnIndexOfDistanceMeters)
          val _tmpPointCount: Int
          _tmpPointCount = _stmt.getLong(_columnIndexOfPointCount).toInt()
          val _tmpLastPointAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfLastPointAtMillis)) {
            _tmpLastPointAtMillis = null
          } else {
            _tmpLastPointAtMillis = _stmt.getLong(_columnIndexOfLastPointAtMillis)
          }
          val _tmpSegment: Int
          _tmpSegment = _stmt.getLong(_columnIndexOfSegment).toInt()
          val _tmpAliveAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfAliveAtMillis)) {
            _tmpAliveAtMillis = null
          } else {
            _tmpAliveAtMillis = _stmt.getLong(_columnIndexOfAliveAtMillis)
          }
          _tmpRecording = RecordingEntity(_tmpId,_tmpStartedAtMillis,_tmpEndedAtMillis,_tmpState,_tmpDistanceMeters,_tmpPointCount,_tmpLastPointAtMillis,_tmpSegment,_tmpAliveAtMillis)
          val _tmpUpload: UploadStatus?
          val _tmpKey_1: Long
          _tmpKey_1 = _stmt.getLong(_columnIndexOfId)
          _tmpUpload = _collectionUpload.get(_tmpKey_1)
          _item = RecordingListItem(_tmpRecording,_tmpUpload)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun pointsAfter(
    recordingId: Long,
    afterId: Long,
    limit: Int,
  ): List<TrackPointEntity> {
    val _sql: String = "SELECT * FROM track_points WHERE recording_id = ? AND id > ? ORDER BY id LIMIT ?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, recordingId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, afterId)
        _argIndex = 3
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfRecordingId: Int = getColumnIndexOrThrow(_stmt, "recording_id")
        val _columnIndexOfSegment: Int = getColumnIndexOrThrow(_stmt, "segment")
        val _columnIndexOfTimeMillis: Int = getColumnIndexOrThrow(_stmt, "time_millis")
        val _columnIndexOfLatitude: Int = getColumnIndexOrThrow(_stmt, "latitude")
        val _columnIndexOfLongitude: Int = getColumnIndexOrThrow(_stmt, "longitude")
        val _columnIndexOfAltitudeMeters: Int = getColumnIndexOrThrow(_stmt, "altitude_meters")
        val _columnIndexOfMslAltitudeMeters: Int = getColumnIndexOrThrow(_stmt, "msl_altitude_meters")
        val _columnIndexOfAccuracyMeters: Int = getColumnIndexOrThrow(_stmt, "accuracy_meters")
        val _columnIndexOfSpeedMetersPerSecond: Int = getColumnIndexOrThrow(_stmt, "speed_mps")
        val _columnIndexOfBearingDegrees: Int = getColumnIndexOrThrow(_stmt, "bearing_degrees")
        val _result: MutableList<TrackPointEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: TrackPointEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpRecordingId: Long
          _tmpRecordingId = _stmt.getLong(_columnIndexOfRecordingId)
          val _tmpSegment: Int
          _tmpSegment = _stmt.getLong(_columnIndexOfSegment).toInt()
          val _tmpTimeMillis: Long
          _tmpTimeMillis = _stmt.getLong(_columnIndexOfTimeMillis)
          val _tmpLatitude: Double
          _tmpLatitude = _stmt.getDouble(_columnIndexOfLatitude)
          val _tmpLongitude: Double
          _tmpLongitude = _stmt.getDouble(_columnIndexOfLongitude)
          val _tmpAltitudeMeters: Double?
          if (_stmt.isNull(_columnIndexOfAltitudeMeters)) {
            _tmpAltitudeMeters = null
          } else {
            _tmpAltitudeMeters = _stmt.getDouble(_columnIndexOfAltitudeMeters)
          }
          val _tmpMslAltitudeMeters: Double?
          if (_stmt.isNull(_columnIndexOfMslAltitudeMeters)) {
            _tmpMslAltitudeMeters = null
          } else {
            _tmpMslAltitudeMeters = _stmt.getDouble(_columnIndexOfMslAltitudeMeters)
          }
          val _tmpAccuracyMeters: Float?
          if (_stmt.isNull(_columnIndexOfAccuracyMeters)) {
            _tmpAccuracyMeters = null
          } else {
            _tmpAccuracyMeters = _stmt.getDouble(_columnIndexOfAccuracyMeters).toFloat()
          }
          val _tmpSpeedMetersPerSecond: Float?
          if (_stmt.isNull(_columnIndexOfSpeedMetersPerSecond)) {
            _tmpSpeedMetersPerSecond = null
          } else {
            _tmpSpeedMetersPerSecond = _stmt.getDouble(_columnIndexOfSpeedMetersPerSecond).toFloat()
          }
          val _tmpBearingDegrees: Float?
          if (_stmt.isNull(_columnIndexOfBearingDegrees)) {
            _tmpBearingDegrees = null
          } else {
            _tmpBearingDegrees = _stmt.getDouble(_columnIndexOfBearingDegrees).toFloat()
          }
          _item = TrackPointEntity(_tmpId,_tmpRecordingId,_tmpSegment,_tmpTimeMillis,_tmpLatitude,_tmpLongitude,_tmpAltitudeMeters,_tmpMslAltitudeMeters,_tmpAccuracyMeters,_tmpSpeedMetersPerSecond,_tmpBearingDegrees)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun recordProgress(
    id: Long,
    distanceMeters: Double,
    pointTimeMillis: Long,
  ) {
    val _sql: String = "UPDATE recordings SET distance_meters = ?, point_count = point_count + 1, last_point_at_millis = ? WHERE id = ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindDouble(_argIndex, distanceMeters)
        _argIndex = 2
        _stmt.bindLong(_argIndex, pointTimeMillis)
        _argIndex = 3
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun markFinished(id: Long, endedAtMillis: Long) {
    val _sql: String = "UPDATE recordings SET state = 'FINISHED', ended_at_millis = ?, alive_at_millis = NULL WHERE id = ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, endedAtMillis)
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun markInterrupted(
    id: Long,
    endedAtMillis: Long,
    aliveAtMillis: Long?,
  ) {
    val _sql: String = "UPDATE recordings SET state = 'INTERRUPTED', ended_at_millis = ?, alive_at_millis = ? WHERE id = ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, endedAtMillis)
        _argIndex = 2
        if (aliveAtMillis == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, aliveAtMillis)
        }
        _argIndex = 3
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun markResumed(
    id: Long,
    segment: Int,
    nowMillis: Long,
  ): Int {
    val _sql: String = "UPDATE recordings SET state = 'RECORDING', ended_at_millis = NULL, segment = ?, alive_at_millis = ? WHERE id = ? AND state = 'INTERRUPTED'"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, segment.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, nowMillis)
        _argIndex = 3
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun markAlive(id: Long, nowMillis: Long) {
    val _sql: String = "UPDATE recordings SET alive_at_millis = ? WHERE id = ? AND state = 'RECORDING'"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, nowMillis)
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun finishInterrupted(id: Long): Int {
    val _sql: String = "UPDATE recordings SET state = 'FINISHED', alive_at_millis = NULL WHERE id = ? AND state = 'INTERRUPTED'"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun deletePoints(recordingId: Long) {
    val _sql: String = "DELETE FROM track_points WHERE recording_id = ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, recordingId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun deleteUnlessRecording(id: Long): Int {
    val _sql: String = "DELETE FROM recordings WHERE id = ? AND state != 'RECORDING'"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun delete(id: Long) {
    val _sql: String = "DELETE FROM recordings WHERE id = ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  private fun __RecordingState_enumToString(_value: RecordingState): String = when (_value) {
    RecordingState.RECORDING -> "RECORDING"
    RecordingState.INTERRUPTED -> "INTERRUPTED"
    RecordingState.FINISHED -> "FINISHED"
  }

  private fun __RecordingState_stringToEnum(_value: String): RecordingState = when (_value) {
    "RECORDING" -> RecordingState.RECORDING
    "INTERRUPTED" -> RecordingState.INTERRUPTED
    "FINISHED" -> RecordingState.FINISHED
    else -> throw IllegalArgumentException("Can't convert value to enum, unknown value: " + _value)
  }

  private fun __UploadState_stringToEnum(_value: String): UploadState = when (_value) {
    "WAITING" -> UploadState.WAITING
    "PENDING" -> UploadState.PENDING
    "DONE" -> UploadState.DONE
    "EXPIRED" -> UploadState.EXPIRED
    "REJECTED" -> UploadState.REJECTED
    "FAILED" -> UploadState.FAILED
    "NOTHING_TO_UPLOAD" -> UploadState.NOTHING_TO_UPLOAD
    "NO_GRANT" -> UploadState.NO_GRANT
    else -> throw IllegalArgumentException("Can't convert value to enum, unknown value: " + _value)
  }

  private fun __fetchRelationshipuploadsAsioGithubMarkusnuoRoutelogDataUploadStatus(_connection: SQLiteConnection, _map: LongSparseArray<UploadStatus?>) {
    if (_map.isEmpty()) {
      return
    }
    if (_map.size() > 999) {
      recursiveFetchLongSparseArray(_map, false) { _tmpMap ->
        __fetchRelationshipuploadsAsioGithubMarkusnuoRoutelogDataUploadStatus(_connection, _tmpMap)
      }
      return
    }
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT `recording_id`,`host`,`label`,`state`,`last_http_status`,`expires_at_millis`,`route_deleted_at_millis` FROM `uploads` WHERE `recording_id` IN (")
    val _inputSize: Int = _map.size()
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    val _stmt: SQLiteStatement = _connection.prepare(_sql)
    var _argIndex: Int = 1
    for (i in 0 until _map.size()) {
      val _item: Long = _map.keyAt(i)
      _stmt.bindLong(_argIndex, _item)
      _argIndex++
    }
    try {
      val _itemKeyIndex: Int = getColumnIndex(_stmt, "recording_id")
      if (_itemKeyIndex == -1) {
        return
      }
      val _columnIndexOfRecordingId: Int = 0
      val _columnIndexOfHost: Int = 1
      val _columnIndexOfLabel: Int = 2
      val _columnIndexOfState: Int = 3
      val _columnIndexOfLastHttpStatus: Int = 4
      val _columnIndexOfExpiresAtMillis: Int = 5
      val _columnIndexOfRouteDeletedAtMillis: Int = 6
      while (_stmt.step()) {
        val _tmpKey: Long
        _tmpKey = _stmt.getLong(_itemKeyIndex)
        if (_map.containsKey(_tmpKey)) {
          val _item_1: UploadStatus?
          val _tmpRecordingId: Long
          _tmpRecordingId = _stmt.getLong(_columnIndexOfRecordingId)
          val _tmpHost: String
          _tmpHost = _stmt.getText(_columnIndexOfHost)
          val _tmpLabel: String?
          if (_stmt.isNull(_columnIndexOfLabel)) {
            _tmpLabel = null
          } else {
            _tmpLabel = _stmt.getText(_columnIndexOfLabel)
          }
          val _tmpState: UploadState
          _tmpState = __UploadState_stringToEnum(_stmt.getText(_columnIndexOfState))
          val _tmpLastHttpStatus: Int?
          if (_stmt.isNull(_columnIndexOfLastHttpStatus)) {
            _tmpLastHttpStatus = null
          } else {
            _tmpLastHttpStatus = _stmt.getLong(_columnIndexOfLastHttpStatus).toInt()
          }
          val _tmpExpiresAtMillis: Long
          _tmpExpiresAtMillis = _stmt.getLong(_columnIndexOfExpiresAtMillis)
          val _tmpRouteDeletedAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfRouteDeletedAtMillis)) {
            _tmpRouteDeletedAtMillis = null
          } else {
            _tmpRouteDeletedAtMillis = _stmt.getLong(_columnIndexOfRouteDeletedAtMillis)
          }
          _item_1 = UploadStatus(_tmpRecordingId,_tmpHost,_tmpLabel,_tmpState,_tmpLastHttpStatus,_tmpExpiresAtMillis,_tmpRouteDeletedAtMillis)
          _map.put(_tmpKey, _item_1)
        }
      }
    } finally {
      _stmt.close()
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
