package io.github.markusnuo.routelog.`data`

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class RoutelogDatabase_Impl : RoutelogDatabase() {
  private val _recordingDao: Lazy<RecordingDao> = lazy {
    RecordingDao_Impl(this)
  }

  private val _uploadDao: Lazy<UploadDao> = lazy {
    UploadDao_Impl(this)
  }

  private val _grantDao: Lazy<GrantDao> = lazy {
    GrantDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(3, "1939628efddd03af3c918902c6559d7e", "dac1b4608aa31a267d478beac78d6345") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `recordings` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `started_at_millis` INTEGER NOT NULL, `ended_at_millis` INTEGER, `state` TEXT NOT NULL, `distance_meters` REAL NOT NULL, `point_count` INTEGER NOT NULL, `last_point_at_millis` INTEGER, `segment` INTEGER NOT NULL, `alive_at_millis` INTEGER)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `track_points` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `recording_id` INTEGER NOT NULL, `segment` INTEGER NOT NULL, `time_millis` INTEGER NOT NULL, `latitude` REAL NOT NULL, `longitude` REAL NOT NULL, `altitude_meters` REAL, `msl_altitude_meters` REAL, `accuracy_meters` REAL, `speed_mps` REAL, `bearing_degrees` REAL, FOREIGN KEY(`recording_id`) REFERENCES `recordings`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_track_points_recording_id` ON `track_points` (`recording_id`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `uploads` (`recording_id` INTEGER NOT NULL, `upload_url` TEXT NOT NULL, `host` TEXT NOT NULL, `label` TEXT, `expires_at_millis` INTEGER NOT NULL, `state` TEXT NOT NULL, `attempts` INTEGER NOT NULL, `last_http_status` INTEGER, `finished_at_millis` INTEGER, `route_deleted_at_millis` INTEGER, PRIMARY KEY(`recording_id`), FOREIGN KEY(`recording_id`) REFERENCES `recordings`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `grants` (`token_hash` TEXT NOT NULL, `recording_id` INTEGER, `expires_at_millis` INTEGER NOT NULL, PRIMARY KEY(`token_hash`), FOREIGN KEY(`recording_id`) REFERENCES `recordings`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_grants_recording_id` ON `grants` (`recording_id`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '1939628efddd03af3c918902c6559d7e')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `recordings`")
        connection.execSQL("DROP TABLE IF EXISTS `track_points`")
        connection.execSQL("DROP TABLE IF EXISTS `uploads`")
        connection.execSQL("DROP TABLE IF EXISTS `grants`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        connection.execSQL("PRAGMA foreign_keys = ON")
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection): RoomOpenDelegate.ValidationResult {
        val _columnsRecordings: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsRecordings.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("started_at_millis", TableInfo.Column("started_at_millis", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("ended_at_millis", TableInfo.Column("ended_at_millis", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("state", TableInfo.Column("state", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("distance_meters", TableInfo.Column("distance_meters", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("point_count", TableInfo.Column("point_count", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("last_point_at_millis", TableInfo.Column("last_point_at_millis", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("segment", TableInfo.Column("segment", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("alive_at_millis", TableInfo.Column("alive_at_millis", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysRecordings: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesRecordings: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoRecordings: TableInfo = TableInfo("recordings", _columnsRecordings, _foreignKeysRecordings, _indicesRecordings)
        val _existingRecordings: TableInfo = read(connection, "recordings")
        if (!_infoRecordings.equals(_existingRecordings)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |recordings(io.github.markusnuo.routelog.data.RecordingEntity).
              | Expected:
              |""".trimMargin() + _infoRecordings + """
              |
              | Found:
              |""".trimMargin() + _existingRecordings)
        }
        val _columnsTrackPoints: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTrackPoints.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrackPoints.put("recording_id", TableInfo.Column("recording_id", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrackPoints.put("segment", TableInfo.Column("segment", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrackPoints.put("time_millis", TableInfo.Column("time_millis", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrackPoints.put("latitude", TableInfo.Column("latitude", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrackPoints.put("longitude", TableInfo.Column("longitude", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrackPoints.put("altitude_meters", TableInfo.Column("altitude_meters", "REAL", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrackPoints.put("msl_altitude_meters", TableInfo.Column("msl_altitude_meters", "REAL", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrackPoints.put("accuracy_meters", TableInfo.Column("accuracy_meters", "REAL", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrackPoints.put("speed_mps", TableInfo.Column("speed_mps", "REAL", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrackPoints.put("bearing_degrees", TableInfo.Column("bearing_degrees", "REAL", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTrackPoints: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysTrackPoints.add(TableInfo.ForeignKey("recordings", "CASCADE", "NO ACTION", listOf("recording_id"), listOf("id")))
        val _indicesTrackPoints: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesTrackPoints.add(TableInfo.Index("index_track_points_recording_id", false, listOf("recording_id"), listOf("ASC")))
        val _infoTrackPoints: TableInfo = TableInfo("track_points", _columnsTrackPoints, _foreignKeysTrackPoints, _indicesTrackPoints)
        val _existingTrackPoints: TableInfo = read(connection, "track_points")
        if (!_infoTrackPoints.equals(_existingTrackPoints)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |track_points(io.github.markusnuo.routelog.data.TrackPointEntity).
              | Expected:
              |""".trimMargin() + _infoTrackPoints + """
              |
              | Found:
              |""".trimMargin() + _existingTrackPoints)
        }
        val _columnsUploads: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsUploads.put("recording_id", TableInfo.Column("recording_id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUploads.put("upload_url", TableInfo.Column("upload_url", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUploads.put("host", TableInfo.Column("host", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUploads.put("label", TableInfo.Column("label", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUploads.put("expires_at_millis", TableInfo.Column("expires_at_millis", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUploads.put("state", TableInfo.Column("state", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUploads.put("attempts", TableInfo.Column("attempts", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUploads.put("last_http_status", TableInfo.Column("last_http_status", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUploads.put("finished_at_millis", TableInfo.Column("finished_at_millis", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUploads.put("route_deleted_at_millis", TableInfo.Column("route_deleted_at_millis", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysUploads: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysUploads.add(TableInfo.ForeignKey("recordings", "CASCADE", "NO ACTION", listOf("recording_id"), listOf("id")))
        val _indicesUploads: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoUploads: TableInfo = TableInfo("uploads", _columnsUploads, _foreignKeysUploads, _indicesUploads)
        val _existingUploads: TableInfo = read(connection, "uploads")
        if (!_infoUploads.equals(_existingUploads)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |uploads(io.github.markusnuo.routelog.data.UploadEntity).
              | Expected:
              |""".trimMargin() + _infoUploads + """
              |
              | Found:
              |""".trimMargin() + _existingUploads)
        }
        val _columnsGrants: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsGrants.put("token_hash", TableInfo.Column("token_hash", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsGrants.put("recording_id", TableInfo.Column("recording_id", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsGrants.put("expires_at_millis", TableInfo.Column("expires_at_millis", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysGrants: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysGrants.add(TableInfo.ForeignKey("recordings", "SET NULL", "NO ACTION", listOf("recording_id"), listOf("id")))
        val _indicesGrants: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesGrants.add(TableInfo.Index("index_grants_recording_id", false, listOf("recording_id"), listOf("ASC")))
        val _infoGrants: TableInfo = TableInfo("grants", _columnsGrants, _foreignKeysGrants, _indicesGrants)
        val _existingGrants: TableInfo = read(connection, "grants")
        if (!_infoGrants.equals(_existingGrants)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |grants(io.github.markusnuo.routelog.data.GrantEntity).
              | Expected:
              |""".trimMargin() + _infoGrants + """
              |
              | Found:
              |""".trimMargin() + _existingGrants)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "recordings", "track_points", "uploads", "grants")
  }

  public override fun clearAllTables() {
    super.performClear(true, "recordings", "track_points", "uploads", "grants")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(RecordingDao::class, RecordingDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(UploadDao::class, UploadDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(GrantDao::class, GrantDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>): List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    _autoMigrations.add(RoutelogDatabase_AutoMigration_1_2_Impl())
    _autoMigrations.add(RoutelogDatabase_AutoMigration_2_3_Impl())
    return _autoMigrations
  }

  public override fun recordingDao(): RecordingDao = _recordingDao.value

  public override fun uploadDao(): UploadDao = _uploadDao.value

  public override fun grantDao(): GrantDao = _grantDao.value
}
