package io.github.markusnuo.routelog.`data`

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.getTotalChangedRows
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class GrantDao_Impl(
  __db: RoomDatabase,
) : GrantDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfGrantEntity: EntityInsertAdapter<GrantEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfGrantEntity = object : EntityInsertAdapter<GrantEntity>() {
      protected override fun createQuery(): String = "INSERT OR ABORT INTO `grants` (`token_hash`,`recording_id`,`expires_at_millis`) VALUES (?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: GrantEntity) {
        statement.bindText(1, entity.tokenHash)
        val _tmpRecordingId: Long? = entity.recordingId
        if (_tmpRecordingId == null) {
          statement.bindNull(2)
        } else {
          statement.bindLong(2, _tmpRecordingId)
        }
        statement.bindLong(3, entity.expiresAtMillis)
      }
    }
  }

  public override fun insert(grant: GrantEntity): Unit = performBlocking(__db, false, true) { _connection ->
    __insertAdapterOfGrantEntity.insert(_connection, grant)
  }

  public override fun grant(tokenHash: String): GrantEntity? {
    val _sql: String = "SELECT * FROM grants WHERE token_hash = ?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, tokenHash)
        val _columnIndexOfTokenHash: Int = getColumnIndexOrThrow(_stmt, "token_hash")
        val _columnIndexOfRecordingId: Int = getColumnIndexOrThrow(_stmt, "recording_id")
        val _columnIndexOfExpiresAtMillis: Int = getColumnIndexOrThrow(_stmt, "expires_at_millis")
        val _result: GrantEntity?
        if (_stmt.step()) {
          val _tmpTokenHash: String
          _tmpTokenHash = _stmt.getText(_columnIndexOfTokenHash)
          val _tmpRecordingId: Long?
          if (_stmt.isNull(_columnIndexOfRecordingId)) {
            _tmpRecordingId = null
          } else {
            _tmpRecordingId = _stmt.getLong(_columnIndexOfRecordingId)
          }
          val _tmpExpiresAtMillis: Long
          _tmpExpiresAtMillis = _stmt.getLong(_columnIndexOfExpiresAtMillis)
          _result = GrantEntity(_tmpTokenHash,_tmpRecordingId,_tmpExpiresAtMillis)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun delete(tokenHash: String) {
    val _sql: String = "DELETE FROM grants WHERE token_hash = ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, tokenHash)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun deleteExpired(nowMillis: Long): Int {
    val _sql: String = "DELETE FROM grants WHERE expires_at_millis <= ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, nowMillis)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
