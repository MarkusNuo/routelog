package io.github.markusnuo.routelog.`data`

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.getTotalChangedRows
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.IllegalArgumentException
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class UploadDao_Impl(
  __db: RoomDatabase,
) : UploadDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfUploadEntity: EntityInsertAdapter<UploadEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfUploadEntity = object : EntityInsertAdapter<UploadEntity>() {
      protected override fun createQuery(): String = "INSERT OR ABORT INTO `uploads` (`recording_id`,`upload_url`,`host`,`label`,`expires_at_millis`,`state`,`attempts`,`last_http_status`,`finished_at_millis`,`route_deleted_at_millis`) VALUES (?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: UploadEntity) {
        statement.bindLong(1, entity.recordingId)
        statement.bindText(2, entity.uploadUrl)
        statement.bindText(3, entity.host)
        val _tmpLabel: String? = entity.label
        if (_tmpLabel == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpLabel)
        }
        statement.bindLong(5, entity.expiresAtMillis)
        statement.bindText(6, __UploadState_enumToString(entity.state))
        statement.bindLong(7, entity.attempts.toLong())
        val _tmpLastHttpStatus: Int? = entity.lastHttpStatus
        if (_tmpLastHttpStatus == null) {
          statement.bindNull(8)
        } else {
          statement.bindLong(8, _tmpLastHttpStatus.toLong())
        }
        val _tmpFinishedAtMillis: Long? = entity.finishedAtMillis
        if (_tmpFinishedAtMillis == null) {
          statement.bindNull(9)
        } else {
          statement.bindLong(9, _tmpFinishedAtMillis)
        }
        val _tmpRouteDeletedAtMillis: Long? = entity.routeDeletedAtMillis
        if (_tmpRouteDeletedAtMillis == null) {
          statement.bindNull(10)
        } else {
          statement.bindLong(10, _tmpRouteDeletedAtMillis)
        }
      }
    }
  }

  public override fun insert(upload: UploadEntity): Unit = performBlocking(__db, false, true) { _connection ->
    __insertAdapterOfUploadEntity.insert(_connection, upload)
  }

  public override fun upload(recordingId: Long): UploadEntity? {
    val _sql: String = "SELECT * FROM uploads WHERE recording_id = ?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, recordingId)
        val _columnIndexOfRecordingId: Int = getColumnIndexOrThrow(_stmt, "recording_id")
        val _columnIndexOfUploadUrl: Int = getColumnIndexOrThrow(_stmt, "upload_url")
        val _columnIndexOfHost: Int = getColumnIndexOrThrow(_stmt, "host")
        val _columnIndexOfLabel: Int = getColumnIndexOrThrow(_stmt, "label")
        val _columnIndexOfExpiresAtMillis: Int = getColumnIndexOrThrow(_stmt, "expires_at_millis")
        val _columnIndexOfState: Int = getColumnIndexOrThrow(_stmt, "state")
        val _columnIndexOfAttempts: Int = getColumnIndexOrThrow(_stmt, "attempts")
        val _columnIndexOfLastHttpStatus: Int = getColumnIndexOrThrow(_stmt, "last_http_status")
        val _columnIndexOfFinishedAtMillis: Int = getColumnIndexOrThrow(_stmt, "finished_at_millis")
        val _columnIndexOfRouteDeletedAtMillis: Int = getColumnIndexOrThrow(_stmt, "route_deleted_at_millis")
        val _result: UploadEntity?
        if (_stmt.step()) {
          val _tmpRecordingId: Long
          _tmpRecordingId = _stmt.getLong(_columnIndexOfRecordingId)
          val _tmpUploadUrl: String
          _tmpUploadUrl = _stmt.getText(_columnIndexOfUploadUrl)
          val _tmpHost: String
          _tmpHost = _stmt.getText(_columnIndexOfHost)
          val _tmpLabel: String?
          if (_stmt.isNull(_columnIndexOfLabel)) {
            _tmpLabel = null
          } else {
            _tmpLabel = _stmt.getText(_columnIndexOfLabel)
          }
          val _tmpExpiresAtMillis: Long
          _tmpExpiresAtMillis = _stmt.getLong(_columnIndexOfExpiresAtMillis)
          val _tmpState: UploadState
          _tmpState = __UploadState_stringToEnum(_stmt.getText(_columnIndexOfState))
          val _tmpAttempts: Int
          _tmpAttempts = _stmt.getLong(_columnIndexOfAttempts).toInt()
          val _tmpLastHttpStatus: Int?
          if (_stmt.isNull(_columnIndexOfLastHttpStatus)) {
            _tmpLastHttpStatus = null
          } else {
            _tmpLastHttpStatus = _stmt.getLong(_columnIndexOfLastHttpStatus).toInt()
          }
          val _tmpFinishedAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfFinishedAtMillis)) {
            _tmpFinishedAtMillis = null
          } else {
            _tmpFinishedAtMillis = _stmt.getLong(_columnIndexOfFinishedAtMillis)
          }
          val _tmpRouteDeletedAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfRouteDeletedAtMillis)) {
            _tmpRouteDeletedAtMillis = null
          } else {
            _tmpRouteDeletedAtMillis = _stmt.getLong(_columnIndexOfRouteDeletedAtMillis)
          }
          _result = UploadEntity(_tmpRecordingId,_tmpUploadUrl,_tmpHost,_tmpLabel,_tmpExpiresAtMillis,_tmpState,_tmpAttempts,_tmpLastHttpStatus,_tmpFinishedAtMillis,_tmpRouteDeletedAtMillis)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun openButExpired(nowMillis: Long): List<Long> {
    val _sql: String = "SELECT recording_id FROM uploads WHERE state IN ('WAITING', 'PENDING') AND expires_at_millis <= ?"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, nowMillis)
        val _result: MutableList<Long> = mutableListOf()
        while (_stmt.step()) {
          val _item: Long
          _item = _stmt.getLong(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun `open`(): List<UploadEntity> {
    val _sql: String = "SELECT * FROM uploads WHERE state IN ('WAITING', 'PENDING')"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfRecordingId: Int = getColumnIndexOrThrow(_stmt, "recording_id")
        val _columnIndexOfUploadUrl: Int = getColumnIndexOrThrow(_stmt, "upload_url")
        val _columnIndexOfHost: Int = getColumnIndexOrThrow(_stmt, "host")
        val _columnIndexOfLabel: Int = getColumnIndexOrThrow(_stmt, "label")
        val _columnIndexOfExpiresAtMillis: Int = getColumnIndexOrThrow(_stmt, "expires_at_millis")
        val _columnIndexOfState: Int = getColumnIndexOrThrow(_stmt, "state")
        val _columnIndexOfAttempts: Int = getColumnIndexOrThrow(_stmt, "attempts")
        val _columnIndexOfLastHttpStatus: Int = getColumnIndexOrThrow(_stmt, "last_http_status")
        val _columnIndexOfFinishedAtMillis: Int = getColumnIndexOrThrow(_stmt, "finished_at_millis")
        val _columnIndexOfRouteDeletedAtMillis: Int = getColumnIndexOrThrow(_stmt, "route_deleted_at_millis")
        val _result: MutableList<UploadEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: UploadEntity
          val _tmpRecordingId: Long
          _tmpRecordingId = _stmt.getLong(_columnIndexOfRecordingId)
          val _tmpUploadUrl: String
          _tmpUploadUrl = _stmt.getText(_columnIndexOfUploadUrl)
          val _tmpHost: String
          _tmpHost = _stmt.getText(_columnIndexOfHost)
          val _tmpLabel: String?
          if (_stmt.isNull(_columnIndexOfLabel)) {
            _tmpLabel = null
          } else {
            _tmpLabel = _stmt.getText(_columnIndexOfLabel)
          }
          val _tmpExpiresAtMillis: Long
          _tmpExpiresAtMillis = _stmt.getLong(_columnIndexOfExpiresAtMillis)
          val _tmpState: UploadState
          _tmpState = __UploadState_stringToEnum(_stmt.getText(_columnIndexOfState))
          val _tmpAttempts: Int
          _tmpAttempts = _stmt.getLong(_columnIndexOfAttempts).toInt()
          val _tmpLastHttpStatus: Int?
          if (_stmt.isNull(_columnIndexOfLastHttpStatus)) {
            _tmpLastHttpStatus = null
          } else {
            _tmpLastHttpStatus = _stmt.getLong(_columnIndexOfLastHttpStatus).toInt()
          }
          val _tmpFinishedAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfFinishedAtMillis)) {
            _tmpFinishedAtMillis = null
          } else {
            _tmpFinishedAtMillis = _stmt.getLong(_columnIndexOfFinishedAtMillis)
          }
          val _tmpRouteDeletedAtMillis: Long?
          if (_stmt.isNull(_columnIndexOfRouteDeletedAtMillis)) {
            _tmpRouteDeletedAtMillis = null
          } else {
            _tmpRouteDeletedAtMillis = _stmt.getLong(_columnIndexOfRouteDeletedAtMillis)
          }
          _item = UploadEntity(_tmpRecordingId,_tmpUploadUrl,_tmpHost,_tmpLabel,_tmpExpiresAtMillis,_tmpState,_tmpAttempts,_tmpLastHttpStatus,_tmpFinishedAtMillis,_tmpRouteDeletedAtMillis)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun doneBefore(cutoffMillis: Long): List<Long> {
    val _sql: String = "SELECT recording_id FROM uploads WHERE state = 'DONE' AND finished_at_millis <= ? AND route_deleted_at_millis IS NULL"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, cutoffMillis)
        val _result: MutableList<Long> = mutableListOf()
        while (_stmt.step()) {
          val _item: Long
          _item = _stmt.getLong(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun markPending(recordingId: Long): Int {
    val _sql: String = "UPDATE uploads SET state = 'PENDING' WHERE recording_id = ? AND state = 'WAITING'"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, recordingId)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun recordAttempt(recordingId: Long, httpStatus: Int?) {
    val _sql: String = "UPDATE uploads SET attempts = attempts + 1, last_http_status = ? WHERE recording_id = ?"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        if (httpStatus == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, httpStatus.toLong())
        }
        _argIndex = 2
        _stmt.bindLong(_argIndex, recordingId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun finish(
    recordingId: Long,
    state: UploadState,
    httpStatus: Int?,
    finishedAtMillis: Long,
  ): Int {
    val _sql: String = "UPDATE uploads SET state = ?, last_http_status = ?, finished_at_millis = ? WHERE recording_id = ? AND state IN ('WAITING', 'PENDING')"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, __UploadState_enumToString(state))
        _argIndex = 2
        if (httpStatus == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, httpStatus.toLong())
        }
        _argIndex = 3
        _stmt.bindLong(_argIndex, finishedAtMillis)
        _argIndex = 4
        _stmt.bindLong(_argIndex, recordingId)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun markRouteDeleted(recordingId: Long, atMillis: Long): Int {
    val _sql: String = "UPDATE uploads SET route_deleted_at_millis = ? WHERE recording_id = ? AND state = 'DONE' AND route_deleted_at_millis IS NULL"
    return performBlocking(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, atMillis)
        _argIndex = 2
        _stmt.bindLong(_argIndex, recordingId)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  private fun __UploadState_enumToString(_value: UploadState): String = when (_value) {
    UploadState.WAITING -> "WAITING"
    UploadState.PENDING -> "PENDING"
    UploadState.DONE -> "DONE"
    UploadState.EXPIRED -> "EXPIRED"
    UploadState.REJECTED -> "REJECTED"
    UploadState.FAILED -> "FAILED"
    UploadState.NOTHING_TO_UPLOAD -> "NOTHING_TO_UPLOAD"
    UploadState.NO_GRANT -> "NO_GRANT"
  }

  private fun __UploadState_stringToEnum(_value: String): UploadState = when (_value) {
    "WAITING" -> UploadState.WAITING
    "PENDING" -> UploadState.PENDING
    "DONE" -> UploadState.DONE
    "EXPIRED" -> UploadState.EXPIRED
    "REJECTED" -> UploadState.REJECTED
    "FAILED" -> UploadState.FAILED
    "NOTHING_TO_UPLOAD" -> UploadState.NOTHING_TO_UPLOAD
    "NO_GRANT" -> UploadState.NO_GRANT
    else -> throw IllegalArgumentException("Can't convert value to enum, unknown value: " + _value)
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
